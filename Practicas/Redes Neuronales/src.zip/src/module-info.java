module redesNeuronales {
	requires neuroph.core;
}